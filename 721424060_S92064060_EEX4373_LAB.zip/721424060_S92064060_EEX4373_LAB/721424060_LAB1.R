##721424060
##S92064060

##QUESTION01_a

V1<-c(10,20,30,40,50,60,70,80,90,100,110,120)
V1

##b
mean(V1)
median(V1)
quantile(V1)
quantile(V1,probs = c(0.25,0.5,0.75))

##c
M1<-matrix(V1,nrow = 4,ncol = 3,byrow = T)
M1

##d
rnames<-c("R1","R2","R3","R4")
cnames<-c("C1","C2","C3")
M1<-matrix(V1,nrow = 4,ncol = 3,byrow = T,dimnames=list(rnames,cnames))
M1

##  QUESTION02_1
##CREATE data frame for employee

EmpID<-1:10
EmpID

EmpName<-c("A", "B", "C", "D", "E", "F", "G", "H", "I", "J")
EmpName

Gender<-c("M", "F", "F", "M", "M", "F", "M", "M", "M", "F")
Gender

Department<-c("IT", "HR", "FINANCE", "FINANCE", "HR", "IT", "IT", "HR", "FINANCE", "IT")
Department

Salary<-c(750, 500, 550, 500, 400, 700, 600, 450, 500, 650)
Salary

EmpData<-data.frame(EmpID,EmpName,Gender,Department,Salary)
EmpData

##ADD bonus
EmpData$Salary<-EmpData$Salary + 100
EmpData

##SELECTED Finance department
FinanceEmployees<-subset(EmpData, Department=="FINANCE")
FinanceEmployees

##high salary employees
HighSalaryEmployees<-EmpData$EmpName[EmpData$Salary>600]
HighSalaryEmployees

##IT department low salary
LowSalaryEmployeesIT<-EmpData$EmpName[EmpData$Department=="IT" & EmpData$Salary<700]
LowSalaryEmployeesIT


##QUESTION03
?mtcars

# Create the mtcars data frame
mtcars <- data.frame(
  name = c("Mazda RX4", "Mazda RX4 wag", "Datsun 710", "Hornet 4 Drive", "Hornet Sportabout", "Valiant"),
  mpg = c(21.0, 21.0, 22.8, 21.4, 18.7, 18.1),
  cyl = c(6, 6, 4, 6, 8, 6),
  disp = c(160, 160, 108, 258, 360, 225),
  hp = c(110, 110, 93, 110, 175, 105),
  drat = c(3.90, 3.90, 3.85, 3.08, 3.15, 2.76),
  wt = c(2.620, 2.875, 2.320, 3.215, 3.440, 3.460),
  qsec = c(16.46, 17.02, 18.61, 19.44, 17.02, 20.22),
  vs = c(0, 0, 1, 1, 0, 1),
  am = c(1, 1, 1, 0, 0, 0),
  gear = c(4, 4, 4, 3, 3, 3),
  carb = c(4, 4, 1, 1, 2, 1)) 

mtcars

##PLOT FOR mpg
plot(mtcars$mpg,
     main="Miles per Gallon(mpg)",
     xlab = "Car Index",
     ylab = "mpg",
     col="Red")

##visualize the disp
boxplot(disp~am,
        data = mtcars,
        main="Displacement by Transmission Type",
        xlab = "Transmission Type(0=auto, 1=manual",
        ylab = "Dispalcement",
        col="green")

##descriptive statistics for wt
summary(mtcars$wt)


##des statistics for wt by engine type
by(mtcars$wt, mtcars$vs, summary)


##calculate deciles for hp
quantile(mtcars$hp, probs = seq(0,1,0.1))
